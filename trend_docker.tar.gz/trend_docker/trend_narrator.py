"""
trend_narrator.py

state_log.py 위에 얹는 발화 계층. LLM에게 "지금 값 + 최근 N개 추세"를
주고 문장을 만들게 한 뒤, 그 문장이 실제 계산된 추세와 일치하는지
자동으로 검증한다.

grounding_check.py가 "숫자를 정확히 인용했는가"를 검증했다면, 이건
한 단계 더 나아가 "방향(오르는 중/내리는 중/안정)을 정확히 말했는가"를
검증한다 — 숫자는 맞게 인용했지만 방향을 반대로 말하는 경우(예: 실제론
내려가는데 "상승하고 있다"고 말하는 경우)를 잡아내기 위함.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Optional

import requests

from state_log import StateLog, LogEntry, compute_trend, compute_stats, is_anomaly

DEFAULT_TIMEOUT = (5, 30)

# 추세를 나타내는 표현 사전 (한국어 + 영어)
_RISING_WORDS = ["상승", "오르", "증가", "올라가", "rising", "increasing", "climbing", "going up"]
_FALLING_WORDS = ["하강", "내리", "감소", "내려가", "falling", "decreasing", "dropping", "going down"]
_STABLE_WORDS = ["안정", "유지", "변화 없", "stable", "steady", "unchanged"]


def _claimed_trend(text: str) -> Optional[str]:
    """텍스트에서 언급된 추세 방향을 추출. 여러 방향이 동시에 언급되면 None(모호)."""
    has_rising = any(w in text for w in _RISING_WORDS)
    has_falling = any(w in text for w in _FALLING_WORDS)
    has_stable = any(w in text for w in _STABLE_WORDS)
    hits = sum([has_rising, has_falling, has_stable])
    if hits != 1:
        return None
    if has_rising:
        return "rising"
    if has_falling:
        return "falling"
    return "stable"


NARRATE_SYSTEM_PROMPT = (
    "You report a sensor reading and its recent trend in one short Korean sentence.\n"
    "Rules:\n"
    "  (1) Quote the current value exactly as given. Never invent numbers.\n"
    "  (2) State the trend using exactly one of: 상승 중, 하강 중, 안정적.\n"
    "      Use only the trend word that matches the given trend label.\n"
    "  (3) Output exactly one sentence. No preamble.\n"
)

NARRATE_USER_TEMPLATE = (
    "현재 값: {value:.1f}{unit}\n"
    "최근 {n}개 기록: {history}\n"
    "계산된 추세: {trend}\n"
    "위 정보를 바탕으로 한 문장으로 보고하라."
)

_TREND_LABEL_KO = {"rising": "상승", "falling": "하강", "stable": "안정", "unknown": "판단 불가"}


@dataclass
class TrendNarrationResult:
    key: str
    current_value: float
    computed_trend: str
    claimed_trend: Optional[str]
    is_anomaly_flag: bool
    answer: str
    latency_sec: float
    http_status: int
    error: str = ""

    @property
    def trend_grounded(self) -> bool:
        """LLM이 언급한 추세가, 실제 계산된 추세와 일치하는가."""
        if self.computed_trend == "unknown":
            return True  # 판단할 근거가 없으면 통과 처리
        return self.claimed_trend == self.computed_trend

    @property
    def ok(self) -> bool:
        return not self.error and self.trend_grounded


def narrate_with_trend(
    key: str,
    current_value: float,
    *,
    log: StateLog,
    unit: str = "",
    window: int = 5,
    url: str,
    model: str,
    timeout=DEFAULT_TIMEOUT,
) -> TrendNarrationResult:
    # 1) 현재 값을 로그에 기록 (LLM 호출 전에 먼저 — 이번 값도 추세 계산에 포함)
    log.append(key, current_value)

    # 2) 최근 window개로 추세/이상치 계산 (결정적, LLM 없음)
    recent = log.recent(key, window)
    trend = compute_trend(recent)
    anomaly = is_anomaly(current_value, recent[:-1])  # 이번 값 자기 자신은 기준에서 제외

    history_str = ", ".join(f"{e.value:.1f}" for e in recent)

    payload = {
        "model": model,
        "temperature": 0.0,
        "max_tokens": 60,
        "messages": [
            {"role": "system", "content": NARRATE_SYSTEM_PROMPT},
            {"role": "user", "content": NARRATE_USER_TEMPLATE.format(
                value=current_value, unit=unit, n=len(recent),
                history=history_str, trend=_TREND_LABEL_KO[trend],
            )},
        ],
    }

    t0 = time.monotonic()
    try:
        r = requests.post(url, json=payload, timeout=timeout)
    except requests.RequestException as e:
        return TrendNarrationResult(
            key=key, current_value=current_value, computed_trend=trend,
            claimed_trend=None, is_anomaly_flag=anomaly, answer="",
            latency_sec=time.monotonic() - t0, http_status=0, error=str(e),
        )
    latency = time.monotonic() - t0

    if r.status_code != 200:
        return TrendNarrationResult(
            key=key, current_value=current_value, computed_trend=trend,
            claimed_trend=None, is_anomaly_flag=anomaly, answer="",
            latency_sec=latency, http_status=r.status_code, error=f"HTTP {r.status_code}",
        )

    try:
        content = r.json()["choices"][0]["message"]["content"].strip()
    except (ValueError, KeyError, IndexError) as e:
        return TrendNarrationResult(
            key=key, current_value=current_value, computed_trend=trend,
            claimed_trend=None, is_anomaly_flag=anomaly, answer="",
            latency_sec=latency, http_status=r.status_code, error=str(e),
        )

    claimed = _claimed_trend(content)
    return TrendNarrationResult(
        key=key, current_value=current_value, computed_trend=trend,
        claimed_trend=claimed, is_anomaly_flag=anomaly, answer=content,
        latency_sec=latency, http_status=r.status_code,
    )

# gpu_trend_monitor — 빌드 & 사용법

이 샌드박스엔 Docker/GPU가 없어 직접 빌드·검증하지 못했습니다.
아래 순서를 선생님 환경에서 진행해주세요.

## 1. 빌드

```bash
tar -xzf trend_docker.tar.gz
cd trend_docker
docker build -t kgh07/gpu_trend_monitor:v1.0 .
```

## 2. 실행 — 반드시 로그 파일을 볼륨 마운트하세요

`--log-path`가 가리키는 파일을 호스트 디렉토리에 마운트해야, 컨테이너를
껐다 켜도(혹은 여러 번 `docker run`을 다시 실행해도) 기록이 유지됩니다.
마운트하지 않으면 컨테이너가 사라지는 순간 로그도 같이 사라집니다.

```bash
mkdir -p ~/gpu_trend_data

# 호스트 IP 확인
ip addr show docker0 | grep inet
```

```bash
docker run --rm -it \
  --device=/dev/kfd --device=/dev/dri \
  --group-add 44 --group-add 992 \
  -e QWEN_URL="http://172.17.0.1:2242/v1/chat/completions" \
  -v ~/gpu_trend_data:/app/data \
  kgh07/gpu_trend_monitor:v1.0 \
  --device 0 --log-path /app/data/gpu_temp_log.jsonl -n 10 --interval 10
```

`-n 10 --interval 10`은 10초 간격으로 10회 반복 측정합니다. 끝나면
`~/gpu_trend_data/gpu_temp_log.jsonl`에 기록이 남고, 나중에 컨테이너를
다시 실행해도 그 파일을 계속 이어서 씁니다.

## 3. 결과 예시

```
[1/10] 값=44.0C 계산추세=unknown LLM주장=stable 방향그라운딩=True 이상치=False latency=3.2s
  답변: 현재 온도는 44.0C이고 안정적입니다.
[2/10] 값=45.0C 계산추세=rising LLM주장=rising 방향그라운딩=True 이상치=False latency=2.8s
  답변: 현재 온도는 45.0C로 상승 중입니다.
...
=== 요약: 10회 중 방향 그라운딩 성공 10회 (100.0%) ===
```

## 4. Docker Hub에 올리기

```bash
docker tag kgh07/gpu_trend_monitor:v1.0 kgh07/gpu_trend_monitor:latest
docker push kgh07/gpu_trend_monitor:v1.0
docker push kgh07/gpu_trend_monitor:latest
```

## 참고: "기억"이 아니라 "로그"입니다

이 이미지가 하는 일은 값을 파일에 순서대로 쌓고, 최근 N개로 추세(상승/
하강/안정)를 계산하고, LLM이 그 방향을 정확히 말하는지 검증하는 것뿐
입니다. 로봇에게 의식이나 경험이 필요하다는 주장과는 무관한, 평범하고
검증 가능한 시계열 로깅 + 그라운딩 검증입니다.

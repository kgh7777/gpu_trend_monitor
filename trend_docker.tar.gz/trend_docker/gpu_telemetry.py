"""
gpu_telemetry.py (v2)

4-way Radeon GPU 텔레메트리 추출기 (RDNA3 / RDNA2 혼합 클러스터용)
- 1차: rocm-smi --json
- 2차: amdgpu_top -d 0,1,2,3 -J
- 둘 다 실패하면 명시적 'unavailable' 마커를 붙여 가짜 수치를 절대 박지 않는다.

v1 대비 수정:
  - [버그 수정] _parse_rocm_smi_card()가 항상 index=-1로 GpuSample을 만들었고,
    호출부에서 실제 idx를 다시 대입해주지 않았다. 그 결과 collect()의
    "누락된 카드는 unavailable로 채운다" 로직이 (index=-1 뿐이라 present={-1})
    항상 0,1,2,3 전부를 '누락'으로 오판해서, 실제 데이터 4개 + 가짜 NA 카드 4개
    총 8개가 반환되는 문제가 있었다. 이제 idx를 명시적으로 전달/대입한다.

추출 대상: 카드별 Temperature(°C), Power(W), VRAM(used MiB), GPU use(%)
"""

from __future__ import annotations

import json
import logging
import re
import shutil
import subprocess
from dataclasses import dataclass, asdict
from typing import Optional

log = logging.getLogger("gpu_telemetry")

# ---------------------------------------------------------------------------
# 데이터 컨테이너
# ---------------------------------------------------------------------------

@dataclass
class GpuSample:
    index: int              # PCI 카드 인덱스 (0,1,2,3 …)
    name: str               # 예: "card0", "device0"
    source: str             # "rocm-smi" | "amdgpu_top" | "unavailable"
    temperature_c: Optional[float] = None
    power_w: Optional[float] = None
    vram_used_mib: Optional[float] = None
    gpu_use_pct: Optional[float] = None

    def has_any(self) -> bool:
        return any(v is not None for v in (
            self.temperature_c, self.power_w, self.vram_used_mib, self.gpu_use_pct,
        ))

    def to_vector_token(self) -> str:
        """
        LLM 입력용 단축 문자열. 모르는 값은 'NA' 로 박는다 (가짜 수치 금지).
        """
        def fmt(v, unit):
            return f"{v:.1f}{unit}" if v is not None else f"NA{unit}"
        return (
            f"[{self.name} "
            f"T:{fmt(self.temperature_c, 'C')},"
            f"P:{fmt(self.power_w, 'W')},"
            f"V:{fmt(self.vram_used_mib, 'MiB')},"
            f"U:{fmt(self.gpu_use_pct, '%')}]"
        )


# ---------------------------------------------------------------------------
# 파서: rocm-smi --json
# ---------------------------------------------------------------------------

_ROCM_TEMP_KEYS = (
    "Temperature (Sensor edge) (C)",
    "Temperature (Edge) (C)",
    "Temperature (C)",
)
_ROCM_POWER_KEYS = (
    "Average Graphics Package Power (W)",
    "Current Socket Graphics Package Power (W)",
    "Power Cap (W)",            # 폴백 (실측이 아니라 cap인 경우 마킹)
    "Average Power (W)",
)
_ROCM_VRAM_KEYS = (
    "GPU memory use (MiB)",
    "VRAM Total Used Memory (MiB)",
    "Used Memory (MiB)",
)
_ROCM_USE_KEYS = (
    "GPU use (%)",
    "GPU Utilization (%)",
)


def _pick(d: dict, keys: tuple[str, ...], cast=float) -> Optional[float]:
    """주어진 dict에서 keys 중 하나를 찾아 숫자로 캐스팅. 모두 실패하면 None."""
    for k in keys:
        if k in d and d[k] not in (None, "", "N/A"):
            try:
                return cast(d[k])
            except (TypeError, ValueError):
                continue
    return None


def _parse_rocm_smi_card(idx: int, name: str, payload: dict) -> GpuSample:
    """idx를 명시적으로 받아 GpuSample.index에 반영한다 (v1 버그 수정 지점)."""
    sample = GpuSample(index=idx, name=name, source="rocm-smi")
    sample.temperature_c = _pick(payload, _ROCM_TEMP_KEYS)
    sample.power_w       = _pick(payload, _ROCM_POWER_KEYS)
    sample.vram_used_mib = _pick(payload, _ROCM_VRAM_KEYS)
    sample.gpu_use_pct   = _pick(payload, _ROCM_USE_KEYS)
    return sample


# ---------------------------------------------------------------------------
# 파서: amdgpu_top -J
# ---------------------------------------------------------------------------

def _parse_amdgpu_top_payload(payload, target_indices=(0, 1, 2, 3)) -> list[GpuSample]:
    """
    amdgpu_top -J 출력은 보통:
      { "0": { "device_name": ..., "metrics": {...}, ... }, "1": {...} }
    형태로 들어온다. 키가 문자열/정수 둘 다일 수 있어 양쪽 다 처리.
    """
    out: list[GpuSample] = []
    if not isinstance(payload, dict):
        return out

    for idx in target_indices:
        node = payload.get(str(idx)) or payload.get(idx)
        if not isinstance(node, dict):
            continue

        sample = GpuSample(index=idx, name=f"card{idx}", source="amdgpu_top")

        metrics = node.get("metrics") or node  # metrics 하위에 있을 수도, 최상위에 있을 수도

        for k in ("temp", "temperature", "Temperature"):
            if k in metrics and metrics[k] not in (None, ""):
                try:
                    sample.temperature_c = float(metrics[k])
                    break
                except (TypeError, ValueError):
                    pass

        for k in ("average_socket_power", "power", "Power"):
            if k in metrics and metrics[k] not in (None, ""):
                try:
                    sample.power_w = float(metrics[k])
                    break
                except (TypeError, ValueError):
                    pass

        for k in ("vram_used", "vram_used_mib", "memory_usage"):
            if k in metrics and metrics[k] not in (None, ""):
                try:
                    sample.vram_used_mib = float(metrics[k])
                    break
                except (TypeError, ValueError):
                    pass

        for k in ("gpu_use", "utilization", "util", "GPU use (%)"):
            if k in metrics and metrics[k] not in (None, ""):
                try:
                    sample.gpu_use_pct = float(metrics[k])
                    break
                except (TypeError, ValueError):
                    pass

        out.append(sample)

    return out


# ---------------------------------------------------------------------------
# 백엔드 호출
# ---------------------------------------------------------------------------

def _run(cmd: list[str], timeout: float) -> Optional[str]:
    if shutil.which(cmd[0]) is None:
        return None
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired:
        log.warning("telemetry command timed out: %s", cmd)
        return None
    except FileNotFoundError:
        return None

    if result.returncode != 0:
        log.warning("telemetry command failed (%s): %s",
                    result.returncode, (result.stderr or "").strip()[:200])
        return None
    return result.stdout


def _collect_via_rocm_smi(target_indices=(0, 1, 2, 3), timeout: float = 2.0) -> Optional[list[GpuSample]]:
    """
    rocm-smi --json 출력. 1.x 구버전은 --json이 dict 하나, 일부 5.x/6.x는
    { "card0": {...}, "card1": {...} } 형태. 둘 다 처리.
    """
    raw = _run([
        "rocm-smi",
        "--json",
        "--showtemp", "--showpower", "--showuse", "--showmeminfo", "vram",
    ], timeout=timeout)
    if raw is None:
        return None

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", raw, re.S)
        if not m:
            return None
        try:
            payload = json.loads(m.group(0))
        except json.JSONDecodeError:
            return None

    if not isinstance(payload, dict):
        return None

    samples: list[GpuSample] = []

    # 형태 (A): {"card0": {...}, "card1": {...}}
    # 형태 (B): {"0": {...}}
    card_keys = [k for k in payload.keys() if re.fullmatch(r"(card|device)?\d+", str(k), re.I)]
    if card_keys:
        for key in sorted(card_keys, key=lambda s: int(re.findall(r"\d+", s)[0])):
            idx = int(re.findall(r"\d+", key)[0])
            if idx not in target_indices:
                continue
            # v1 버그 수정: idx를 반드시 함께 넘겨서 sample.index가 -1로 남지 않게 한다.
            samples.append(_parse_rocm_smi_card(idx, f"card{idx}", payload[key]))
        return samples

    # 형태 (C): 최상위 dict 하나에 카드들이 알 수 없는 형태로 들어있는 구버전 → 실패로 처리
    return None


def _collect_via_amdgpu_top(target_indices=(0, 1, 2, 3), timeout: float = 2.0) -> Optional[list[GpuSample]]:
    raw = _run(
        ["amdgpu_top", "-d", ",".join(str(i) for i in target_indices), "-J"],
        timeout=timeout,
    )
    if raw is None:
        return None

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", raw, re.S)
        if not m:
            return None
        try:
            payload = json.loads(m.group(0))
        except json.JSONDecodeError:
            return None

    samples = _parse_amdgpu_top_payload(payload, target_indices)
    return samples if samples else None


# ---------------------------------------------------------------------------
# 공개 API
# ---------------------------------------------------------------------------

def collect(target_indices=(0, 1, 2, 3), timeout: float = 2.0) -> list[GpuSample]:
    """
    4개 카드의 텔레메트리를 수집한다. 우선순위:
      1) rocm-smi --json
      2) amdgpu_top -J
      3) 둘 다 실패하면 모든 필드가 None인 'unavailable' 샘플 반환
    카드 인덱스는 항상 0..N-1 순서로 정렬해 돌려준다.
    """
    samples = _collect_via_rocm_smi(target_indices, timeout=timeout)
    backend = "rocm-smi"
    if not samples:
        samples = _collect_via_amdgpu_top(target_indices, timeout=timeout)
        backend = "amdgpu_top"

    samples = samples or []

    # 정상 백엔드로 채워진 것 외에는 source를 백엔드 이름으로 통일
    for s in samples:
        if s.source in ("rocm-smi", "amdgpu_top"):
            s.source = backend

    # 누락된 카드만 'unavailable' 마커로 채움 (가짜 수치 X)
    # index가 이제 정확히 채워지므로, present 집합도 실제 카드 번호를 담게 된다.
    present = {s.index for s in samples}
    for idx in target_indices:
        if idx not in present:
            samples.append(GpuSample(index=idx, name=f"card{idx}", source="unavailable"))

    return sorted(samples, key=lambda s: s.index)


def to_vector_string(samples: list[GpuSample]) -> str:
    """
    LLM 입력용 한 줄 문자열.
    예: "[card0 T:38.0C,P:55.0W,V:1024.0MiB,U:12.0%] [card1 ...]"
    """
    return " ".join(s.to_vector_token() for s in samples)


def to_dict(samples: list[GpuSample]) -> list[dict]:
    return [asdict(s) for s in samples]


# ---------------------------------------------------------------------------
# 데모 / 스모크 테스트 (실제 GPU 없으면 그냥 unavailable 반환)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    samples = collect()
    print("Vector:", to_vector_string(samples))
    print("Detail:", json.dumps(to_dict(samples), indent=2, ensure_ascii=False))

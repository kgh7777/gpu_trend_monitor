"""
gpu_trend_monitor.py

지금까지 손으로 반복 실행하던 python3 -c "..." 명령을 CLI로 정리한 것.
device0 온도를 읽어 state_log에 기록하고, trend_narrator로 방향까지
포함한 문장을 만들어 grounding(숫자 정확성) + 방향 그라운딩을 자동
검증한다.

로그 파일은 컨테이너 밖 볼륨에 마운트해서 써야, 컨테이너를 껐다 켜도
기록이 유지된다 (이게 "기억"이 아니라 그냥 "파일에 로그가 있다"는 뜻
이라는 건 이전과 동일 — 컨테이너가 지워지면 마운트 안 된 파일은
그냥 다른 모든 파일처럼 사라진다).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import time

import gpu_telemetry as gt
from state_log import StateLog
import trend_narrator as tn

log = logging.getLogger("gpu_trend_monitor")

DEFAULT_URL = os.environ.get("QWEN_URL", "http://localhost:2242/v1/chat/completions")
DEFAULT_MODEL = os.environ.get("QWEN_MODEL", "qwen2.5-32b-instruct-q4_k_m")


def run_once(device_index, log_path, window, url, model):
    state_log = StateLog(log_path)
    samples = gt.collect(target_indices=(device_index,))
    temp = samples[0].temperature_c if samples else None

    if temp is None:
        log.warning("device%d 온도를 읽지 못했습니다 (NA). 이번 회차는 건너뜁니다.", device_index)
        return None

    key = f"device{device_index}.temp"
    return tn.narrate_with_trend(
        key, temp, log=state_log, unit="C", window=window, url=url, model=model,
    )


def main():
    p = argparse.ArgumentParser(description="GPU 온도 추세 모니터 (state_log + trend_narrator)")
    p.add_argument("--device", "-d", type=int, default=0)
    p.add_argument("--log-path", type=str, default="/app/data/gpu_temp_log.jsonl")
    p.add_argument("--window", type=int, default=5)
    p.add_argument("--url", type=str, default=DEFAULT_URL)
    p.add_argument("--model", type=str, default=DEFAULT_MODEL)
    p.add_argument("-n", "--count", type=int, default=1, help="반복 횟수")
    p.add_argument("--interval", type=float, default=10.0, help="반복 간 대기 시간(초)")
    args = p.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    n_ok = 0
    n_total = 0
    for i in range(1, args.count + 1):
        result = run_once(args.device, args.log_path, args.window, args.url, args.model)
        if result is None:
            continue
        n_total += 1
        if result.ok:
            n_ok += 1

        print(f"[{i}/{args.count}] "
              f"값={result.current_value:.1f}C "
              f"계산추세={result.computed_trend} "
              f"LLM주장={result.claimed_trend} "
              f"방향그라운딩={result.trend_grounded} "
              f"이상치={result.is_anomaly_flag} "
              f"latency={result.latency_sec:.2f}s")
        print(f"  답변: {result.answer}")
        if result.error:
            print(f"  에러: {result.error}")

        if i < args.count:
            time.sleep(args.interval)

    if n_total:
        print(f"\n=== 요약: {n_total}회 중 방향 그라운딩 성공 {n_ok}회 ({100.0*n_ok/n_total:.1f}%) ===")


if __name__ == "__main__":
    main()

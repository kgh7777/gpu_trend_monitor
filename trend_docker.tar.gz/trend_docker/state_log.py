"""
state_log.py

측정값의 시계열 상태 로그. "기억"이나 "경험"이라고 부르지 않는다 —
이건 파일에 값을 순서대로 쌓고 다시 읽는, 아주 평범한 로깅이다.
(이전 대화에서 합의한 대로: 로봇에게 의식이 필요 없듯 경험도 필요 없다.
 여기서 만드는 건 그냥 "최근 N개 값을 참조할 수 있게 하는 기능"이다.)

용도: "지금 이 값이 지난 값들보다 오르는 중인지, 내리는 중인지, 이상치인지"
같은, 단일 시점 값만으로는 답할 수 없는 질문에 답하기 위함.
"""

from __future__ import annotations

import json
import os
import statistics
import time
from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class LogEntry:
    timestamp: float
    key: str          # 무엇을 측정했는지 (예: "device0.temperature_c")
    value: float

    def to_dict(self) -> dict:
        return asdict(self)


class StateLog:
    """
    JSON Lines 파일에 값을 append하고, 최근 N개를 조회하는 아주 단순한 로거.
    프로세스가 재시작되어도 파일에 남은 기록은 그대로 읽을 수 있다
    (이게 "기억"이 아니라 그냥 "파일에 로그가 있다"는 뜻이다).
    """

    def __init__(self, path: str):
        self.path = path

    def append(self, key: str, value: float, timestamp: Optional[float] = None) -> LogEntry:
        entry = LogEntry(timestamp=timestamp or time.time(), key=key, value=value)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry.to_dict(), ensure_ascii=False) + "\n")
        return entry

    def read_all(self, key: Optional[str] = None) -> list[LogEntry]:
        if not os.path.exists(self.path):
            return []
        out = []
        with open(self.path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                d = json.loads(line)
                if key is not None and d.get("key") != key:
                    continue
                out.append(LogEntry(**d))
        return out

    def recent(self, key: str, n: int) -> list[LogEntry]:
        entries = self.read_all(key=key)
        return entries[-n:]

    def clear(self):
        if os.path.exists(self.path):
            os.remove(self.path)


# ---------------------------------------------------------------------------
# 추세/이상치 계산 (결정적, LLM 없음)
# ---------------------------------------------------------------------------

def compute_trend(entries: list[LogEntry], flat_threshold: float = 0.5) -> str:
    """
    최근 값들의 추세를 판정. "rising" | "falling" | "stable" | "unknown"(데이터 부족).
    flat_threshold: 처음-마지막 값 차이가 이 값 이하면 "stable"로 본다.
    """
    if len(entries) < 2:
        return "unknown"
    first, last = entries[0].value, entries[-1].value
    diff = last - first
    if abs(diff) <= flat_threshold:
        return "stable"
    return "rising" if diff > 0 else "falling"


def compute_stats(entries: list[LogEntry]) -> dict:
    if not entries:
        return {"min": None, "max": None, "avg": None, "n": 0}
    values = [e.value for e in entries]
    return {
        "min": min(values),
        "max": max(values),
        "avg": round(statistics.fmean(values), 2),
        "n": len(values),
    }


def is_anomaly(current_value: float, entries: list[LogEntry], z_threshold: float = 2.5) -> bool:
    """
    entries(과거 기록, current_value 제외)의 평균/표준편차 기준으로,
    current_value가 z_threshold 표준편차를 벗어나면 이상치로 판정.
    데이터가 3개 미만이면 판정 불가로 False를 반환 (성급한 이상치 판정 방지).
    """
    if len(entries) < 3:
        return False
    values = [e.value for e in entries]
    mean = statistics.fmean(values)
    stdev = statistics.pstdev(values)
    if stdev == 0:
        return current_value != mean
    z = abs(current_value - mean) / stdev
    return z >= z_threshold
